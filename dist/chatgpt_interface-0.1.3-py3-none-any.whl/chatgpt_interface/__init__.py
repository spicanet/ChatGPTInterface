# __init__.py
from .chatgpt_interface import ChatGPTInterface
